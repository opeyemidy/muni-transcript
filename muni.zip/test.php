
<?php
function multiply($value){
    $value*=2;
   return $value;
}


echo multiply(4);
?>